import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import profileImage from '../assets/1000015450.jpg';

gsap.registerPlugin(ScrollTrigger);

const AboutSection = () => {
  const sectionRef = useRef(null);
  const imageRef = useRef(null);
  const contentRef = useRef(null);
  const imageContainerRef = useRef(null);

  useEffect(() => {
    const section = sectionRef.current;
    const image = imageRef.current;
    const content = contentRef.current;
    const imageContainer = imageContainerRef.current;

    // Initial setup - image starts from off-screen
    gsap.set(image, {
      x: -window.innerWidth,
      y: 0,
      scale: 0.8,
      rotation: -10,
      opacity: 0
    });

    // Image entrance animation
    const entranceTl = gsap.timeline({
      scrollTrigger: {
        trigger: section,
        start: "top 80%",
        end: "top 20%",
        toggleActions: "play none none reverse"
      }
    });

    entranceTl
      .to(image, {
        x: 0,
        y: 0,
        scale: 1,
        rotation: 0,
        opacity: 1,
        duration: 1.2,
        ease: "power3.out"
      })
      .fromTo(content.children,
        { 
          opacity: 0, 
          y: 50,
          stagger: 0.1
        },
        { 
          opacity: 1, 
          y: 0, 
          stagger: 0.1,
          duration: 0.8,
          ease: "power2.out"
        }, "-=0.8"
      );

    // Pin image to top-left during scroll
    const pinTl = gsap.timeline({
      scrollTrigger: {
        trigger: section,
        start: "center center",
        end: "bottom top",
        scrub: 1,
        onUpdate: (self) => {
          const progress = self.progress;
          
          // Move image to top-left corner as user scrolls
          gsap.to(imageContainer, {
            x: -200 * progress,
            y: -150 * progress,
            scale: 0.6 + (0.4 * (1 - progress)),
            duration: 0.1,
            ease: "none"
          });
        }
      }
    });

    return () => {
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  const stats = [
    { label: "Projects Completed", value: "15+" },
    { label: "Technologies Mastered", value: "20+" },
    { label: "CGPA", value: "8.67" },
    { label: "Certifications", value: "10+" }
  ];

  return (
    <section id="about" ref={sectionRef} className="min-h-screen py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Image Section */}
          <div className="relative">
            <div ref={imageContainerRef} className="relative w-80 h-80 mx-auto lg:mx-0">
              <div className="relative w-full h-full rounded-2xl overflow-hidden">
                <img
                  ref={imageRef}
                  src={profileImage}
                  alt="Pawan Kumar"
                  className="w-full h-full object-cover transform-gpu"
                />
                {/* Subtle border glow instead of glass overlay */}
                <div className="absolute inset-0 rounded-2xl border-2 border-primary/30 pointer-events-none"></div>
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-tr from-transparent via-transparent to-primary/10 pointer-events-none"></div>
              </div>
              
              {/* Floating elements around image */}
              <div className="absolute -top-4 -right-4 w-8 h-8 bg-primary/20 rounded-full animate-pulse"></div>
              <div className="absolute -bottom-4 -left-4 w-6 h-6 bg-accent/20 rounded-full animate-pulse" style={{ animationDelay: '0.5s' }}></div>
              <div className="absolute top-1/2 -right-6 w-4 h-4 bg-secondary/20 rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
            </div>
          </div>

          {/* Content Section */}
          <div ref={contentRef} className="space-y-8">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold tech-text mb-6">
                About Me
              </h2>
              <div className="space-y-4 text-lg text-muted-foreground">
                <p>
                  I'm a passionate AI/ML Developer and Software Engineer currently pursuing B.Tech at 
                  Heritage Institute of Technology, Kolkata. With a strong foundation in machine learning, 
                  web development, and data science, I love creating innovative solutions that bridge 
                  technology and real-world problems.
                </p>
                <p>
                  Currently working as an SDE Intern at BlueStock, I specialize in developing intelligent 
                  applications using Python, Django, and modern ML frameworks. My journey includes 
                  building everything from disease prediction models to smart farming assistants.
                </p>
                <p>
                  When I'm not coding, you'll find me exploring the latest in AI research, participating 
                  in hackathons, or contributing to open-source projects. I believe in continuous learning 
                  and pushing the boundaries of what's possible with technology.
                </p>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <div 
                  key={index} 
                  className="glass-card p-6 text-center hover:scale-105 transition-transform duration-300 cursor-pointer group"
                >
                  <div className="text-3xl font-bold tech-text mb-2 group-hover:text-primary transition-colors duration-300">
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="glass-button px-6 py-3 rounded-full font-medium group relative overflow-hidden">
                <span className="relative z-10">Download Resume</span>
                <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </button>
              <button className="glass px-6 py-3 rounded-full font-medium group relative overflow-hidden">
                <span className="relative z-10">View Projects</span>
                <div className="absolute inset-0 bg-gradient-to-r from-accent/20 to-primary/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Additional CSS for enhanced animations */}
      <style jsx>{`
        .transform-gpu {
          transform: translateZ(0);
          backface-visibility: hidden;
        }
      `}</style>
    </section>
  );
};

export default AboutSection;

