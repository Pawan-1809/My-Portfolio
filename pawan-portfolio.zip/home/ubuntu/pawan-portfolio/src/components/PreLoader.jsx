import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';

const PreLoader = ({ onComplete }) => {
  const preloaderRef = useRef(null);
  const logoRef = useRef(null);
  const progressRef = useRef(null);
  const circleRef = useRef(null);
  const textRef = useRef(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const tl = gsap.timeline();
    
    // Initial setup
    gsap.set(preloaderRef.current, { opacity: 1 });
    gsap.set(logoRef.current, { scale: 0, rotation: -180 });
    gsap.set(progressRef.current, { width: "0%" });
    gsap.set(textRef.current, { opacity: 0, y: 20 });

    // Logo animation
    tl.to(logoRef.current, {
      scale: 1,
      rotation: 0,
      duration: 1,
      ease: "back.out(1.7)"
    })
    .to(textRef.current, {
      opacity: 1,
      y: 0,
      duration: 0.5
    }, "-=0.3");

    // Progress simulation
    const progressInterval = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + Math.random() * 15;
        if (newProgress >= 100) {
          clearInterval(progressInterval);
          
          // Complete animation
          gsap.to(progressRef.current, {
            width: "100%",
            duration: 0.3,
            onComplete: () => {
              gsap.to(preloaderRef.current, {
                opacity: 0,
                scale: 1.1,
                duration: 0.8,
                ease: "power2.inOut",
                onComplete: () => {
                  onComplete();
                }
              });
            }
          });
          
          return 100;
        }
        return newProgress;
      });
    }, 100);

    // Cleanup
    return () => {
      clearInterval(progressInterval);
    };
  }, [onComplete]);

  useEffect(() => {
    gsap.to(progressRef.current, {
      width: `${progress}%`,
      duration: 0.3,
      ease: "power2.out"
    });

    // Rotate circle based on progress
    gsap.to(circleRef.current, {
      rotation: progress * 3.6,
      duration: 0.3,
      ease: "power2.out"
    });
  }, [progress]);

  return (
    <div 
      ref={preloaderRef}
      className="fixed inset-0 z-50 flex items-center justify-center bg-background"
    >
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-accent/5 to-secondary/5"></div>
        
        {/* Floating Particles */}
        <div className="particle-container">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="particle"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${3 + Math.random() * 4}s`
              }}
            />
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 text-center">
        {/* Logo */}
        <div ref={logoRef} className="mb-8">
          <div className="relative">
            <div 
              ref={circleRef}
              className="w-24 h-24 mx-auto mb-4 border-4 border-primary/30 rounded-full relative"
            >
              <div className="absolute inset-2 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center">
                <span className="text-2xl font-bold text-white">PK</span>
              </div>
              <div className="absolute -inset-2 border-2 border-accent/20 rounded-full animate-spin-slow"></div>
            </div>
          </div>
        </div>

        {/* Loading Text */}
        <div ref={textRef} className="mb-8">
          <h2 className="text-2xl font-bold tech-text mb-2">
            Loading Portfolio
          </h2>
          <p className="text-muted-foreground">
            Initializing AI/ML Experience...
          </p>
        </div>

        {/* Progress Bar */}
        <div className="w-64 mx-auto">
          <div className="glass rounded-full h-2 overflow-hidden mb-4">
            <div 
              ref={progressRef}
              className="h-full bg-gradient-to-r from-primary to-accent rounded-full transition-all duration-300"
            />
          </div>
          <div className="text-sm text-muted-foreground">
            {Math.round(progress)}%
          </div>
        </div>

        {/* Tech Keywords */}
        <div className="mt-8 flex flex-wrap justify-center gap-2 opacity-50">
          {['React', 'GSAP', 'AI/ML', 'Python', 'Django'].map((tech, index) => (
            <span
              key={tech}
              className="text-xs px-2 py-1 glass rounded-full"
              style={{
                animationDelay: `${index * 0.2}s`
              }}
            >
              {tech}
            </span>
          ))}
        </div>
      </div>

      {/* CSS Styles */}
      <style jsx>{`
        .particle-container {
          position: absolute;
          inset: 0;
          pointer-events: none;
        }

        .particle {
          position: absolute;
          width: 4px;
          height: 4px;
          background: linear-gradient(45deg, #3b82f6, #8b5cf6);
          border-radius: 50%;
          animation: float-particle linear infinite;
        }

        @keyframes float-particle {
          0% {
            transform: translateY(100vh) rotate(0deg);
            opacity: 0;
          }
          10% {
            opacity: 1;
          }
          90% {
            opacity: 1;
          }
          100% {
            transform: translateY(-10vh) rotate(360deg);
            opacity: 0;
          }
        }

        .animate-spin-slow {
          animation: spin 3s linear infinite;
        }

        @keyframes spin {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(360deg);
          }
        }
      `}</style>
    </div>
  );
};

export default PreLoader;

