import { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronDown, Play, Pause } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const HeroSection = () => {
  const heroRef = useRef(null);
  const nameRef = useRef(null);
  const titleRef = useRef(null);
  const buttonsRef = useRef(null);
  const geometryRef = useRef(null);
  const floatingElementsRef = useRef(null);
  const rippleContainerRef = useRef(null);
  const [isVideoPlaying, setIsVideoPlaying] = useState(true);

  useEffect(() => {
    const tl = gsap.timeline({ delay: 0.5 });
    
    // Stairs-type landing animation
    tl.fromTo(nameRef.current.children,
      { 
        y: 100, 
        opacity: 0, 
        rotationX: 90,
        transformOrigin: "50% 100%"
      },
      { 
        y: 0, 
        opacity: 1, 
        rotationX: 0,
        stagger: 0.1,
        duration: 1.2,
        ease: "power3.out"
      }
    )
    .fromTo(titleRef.current,
      { 
        y: 50, 
        opacity: 0,
        scale: 0.8
      },
      { 
        y: 0, 
        opacity: 1,
        scale: 1,
        duration: 0.8,
        ease: "power3.out"
      }, "-=0.6"
    )
    .fromTo(buttonsRef.current.children,
      { 
        y: 30, 
        opacity: 0,
        scale: 0.9
      },
      { 
        y: 0, 
        opacity: 1,
        scale: 1,
        stagger: 0.1,
        duration: 0.6,
        ease: "power3.out"
      }, "-=0.4"
    );

    // Floating elements animation
    gsap.to(floatingElementsRef.current.children, {
      y: "random(-20, 20)",
      x: "random(-10, 10)",
      rotation: "random(-5, 5)",
      duration: "random(3, 6)",
      repeat: -1,
      yoyo: true,
      ease: "power1.inOut",
      stagger: {
        amount: 2,
        from: "random"
      }
    });

    // Geometrical illusion animation
    gsap.to(geometryRef.current, {
      rotation: 360,
      duration: 20,
      repeat: -1,
      ease: "none"
    });

    // Parallax effect on scroll
    gsap.to(heroRef.current, {
      yPercent: -50,
      ease: "none",
      scrollTrigger: {
        trigger: heroRef.current,
        start: "top top",
        end: "bottom top",
        scrub: true
      }
    });

  }, []);

  const createRipple = (e) => {
    const rect = rippleContainerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Create ripple element
    const ripple = document.createElement('div');
    ripple.className = 'ripple-effect';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    
    rippleContainerRef.current.appendChild(ripple);

    // Animate ripple
    gsap.fromTo(ripple, 
      { 
        scale: 0, 
        opacity: 1 
      },
      { 
        scale: 4, 
        opacity: 0, 
        duration: 1.5,
        ease: "power2.out",
        onComplete: () => ripple.remove()
      }
    );

    // Create drop effect
    const drop = document.createElement('div');
    drop.className = 'drop-effect';
    drop.style.left = x + 'px';
    drop.style.top = y + 'px';
    
    rippleContainerRef.current.appendChild(drop);

    gsap.fromTo(drop,
      { 
        y: 0, 
        opacity: 1, 
        scale: 1 
      },
      { 
        y: 100, 
        opacity: 0, 
        scale: 0.5,
        duration: 1,
        ease: "power2.in",
        onComplete: () => drop.remove()
      }
    );
  };

  const toggleVideo = () => {
    const video = document.querySelector('.hero-video');
    if (video) {
      if (isVideoPlaying) {
        video.pause();
      } else {
        video.play();
      }
      setIsVideoPlaying(!isVideoPlaying);
    }
  };

  return (
    <section 
      id="home" 
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      onClick={createRipple}
    >
      {/* Background Video */}
      <div className="absolute inset-0 z-0">
        <video
          className="hero-video w-full h-full object-cover"
          autoPlay
          muted
          loop
          playsInline
        >
          <source src="https://assets.mixkit.co/videos/preview/mixkit-digital-futuristic-tunnel-with-neon-lights-32736-large.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-gradient-to-br from-background/90 via-background/70 to-background/90"></div>
      </div>

      {/* Ripple Container */}
      <div ref={rippleContainerRef} className="absolute inset-0 z-10 pointer-events-none"></div>

      {/* Geometrical Illusion */}
      <div ref={geometryRef} className="absolute top-20 right-20 z-10 opacity-20">
        <div className="geometric-illusion">
          <div className="cube-container">
            <div className="cube">
              <div className="face front"></div>
              <div className="face back"></div>
              <div className="face right"></div>
              <div className="face left"></div>
              <div className="face top"></div>
              <div className="face bottom"></div>
            </div>
          </div>
        </div>
      </div>

      {/* 3D Floating Elements */}
      <div ref={floatingElementsRef} className="absolute inset-0 z-10 pointer-events-none">
        <div className="floating-element absolute top-20 left-20 text-6xl font-bold text-primary/20 transform-gpu">
          AI
        </div>
        <div className="floating-element absolute top-40 right-40 text-5xl font-bold text-accent/20 transform-gpu">
          ML
        </div>
        <div className="floating-element absolute bottom-40 left-40 text-4xl font-bold text-secondary/20 transform-gpu">
          CODE
        </div>
        <div className="floating-element absolute bottom-20 right-20 text-7xl font-bold text-primary/20 transform-gpu">
          TECH
        </div>
        <div className="floating-element absolute top-1/2 left-10 text-3xl font-bold text-accent/20 transform-gpu">
          DEV
        </div>
        <div className="floating-element absolute top-60 right-60 text-5xl font-bold text-secondary/20 transform-gpu">
          DATA
        </div>
        <div className="floating-element absolute bottom-60 left-60 text-4xl font-bold text-primary/20 transform-gpu">
          WEB
        </div>
        <div className="floating-element absolute top-80 left-80 text-6xl font-bold text-accent/20 transform-gpu">
          API
        </div>
      </div>

      {/* 3D Tech Models */}
      <div className="absolute inset-0 z-10 pointer-events-none">
        <div className="tech-model absolute top-32 left-32 opacity-30">
          <div className="monitor-3d">
            <div className="monitor-screen">
              <div className="code-lines">
                <div className="code-line"></div>
                <div className="code-line"></div>
                <div className="code-line"></div>
                <div className="code-line"></div>
              </div>
            </div>
            <div className="monitor-base"></div>
          </div>
        </div>
        
        <div className="tech-model absolute bottom-32 right-32 opacity-30">
          <div className="server-rack">
            <div className="server-unit"></div>
            <div className="server-unit"></div>
            <div className="server-unit"></div>
            <div className="server-lights">
              <div className="light"></div>
              <div className="light"></div>
              <div className="light"></div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-20 text-center px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <div ref={nameRef} className="mb-8">
          <div className="text-6xl md:text-8xl lg:text-9xl font-black tech-text mb-4 perspective-1000">
            <span className="inline-block transform-gpu">P</span>
            <span className="inline-block transform-gpu">A</span>
            <span className="inline-block transform-gpu">W</span>
            <span className="inline-block transform-gpu">A</span>
            <span className="inline-block transform-gpu">N</span>
          </div>
          <div className="text-6xl md:text-8xl lg:text-9xl font-black tech-text perspective-1000">
            <span className="inline-block transform-gpu">K</span>
            <span className="inline-block transform-gpu">U</span>
            <span className="inline-block transform-gpu">M</span>
            <span className="inline-block transform-gpu">A</span>
            <span className="inline-block transform-gpu">R</span>
          </div>
        </div>

        <div ref={titleRef} className="mb-12">
          <h2 className="text-2xl md:text-3xl lg:text-4xl text-muted-foreground font-light tracking-wide">
            AI/ML Developer & Software Engineer
          </h2>
          <div className="mt-4 h-1 w-32 bg-gradient-to-r from-primary to-accent mx-auto rounded-full"></div>
        </div>

        <div ref={buttonsRef} className="flex flex-col sm:flex-row gap-6 justify-center items-center">
          <button 
            className="glass-button px-8 py-4 rounded-full font-medium text-lg group relative overflow-hidden"
            onClick={() => gsap.to(window, { duration: 1, scrollTo: "#projects", ease: "power2.out" })}
          >
            <span className="relative z-10 flex items-center gap-2">
              View My Work
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </button>
          
          <button 
            className="glass-button px-8 py-4 rounded-full font-medium text-lg group relative overflow-hidden"
            onClick={() => gsap.to(window, { duration: 1, scrollTo: "#contact", ease: "power2.out" })}
          >
            <span className="relative z-10 flex items-center gap-2">
              Get In Touch
              <div className="w-2 h-2 bg-accent rounded-full animate-pulse"></div>
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-accent/20 to-primary/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </button>
        </div>

        {/* Video Control */}
        <button
          onClick={toggleVideo}
          className="absolute bottom-8 left-8 glass p-3 rounded-full hover:bg-primary/20 transition-colors duration-300 z-30"
        >
          {isVideoPlaying ? <Pause size={20} /> : <Play size={20} />}
        </button>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20">
        <div className="flex flex-col items-center animate-bounce">
          <span className="text-sm text-muted-foreground mb-2">Scroll to explore</span>
          <ChevronDown size={24} className="text-primary" />
        </div>
      </div>

      {/* Additional CSS Styles */}
      <style jsx>{`
        .ripple-effect {
          position: absolute;
          border: 2px solid rgba(59, 130, 246, 0.6);
          border-radius: 50%;
          pointer-events: none;
          transform: translate(-50%, -50%);
        }
        
        .drop-effect {
          position: absolute;
          width: 8px;
          height: 8px;
          background: linear-gradient(45deg, #3b82f6, #8b5cf6);
          border-radius: 50%;
          pointer-events: none;
          transform: translate(-50%, -50%);
        }

        .geometric-illusion {
          width: 200px;
          height: 200px;
          perspective: 1000px;
        }

        .cube-container {
          width: 100%;
          height: 100%;
          position: relative;
          transform-style: preserve-3d;
        }

        .cube {
          width: 100px;
          height: 100px;
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%) rotateX(45deg) rotateY(45deg);
          transform-style: preserve-3d;
        }

        .face {
          position: absolute;
          width: 100px;
          height: 100px;
          border: 2px solid rgba(59, 130, 246, 0.3);
          background: rgba(59, 130, 246, 0.1);
        }

        .front { transform: rotateY(0deg) translateZ(50px); }
        .back { transform: rotateY(180deg) translateZ(50px); }
        .right { transform: rotateY(90deg) translateZ(50px); }
        .left { transform: rotateY(-90deg) translateZ(50px); }
        .top { transform: rotateX(90deg) translateZ(50px); }
        .bottom { transform: rotateX(-90deg) translateZ(50px); }

        .monitor-3d {
          width: 120px;
          height: 80px;
          position: relative;
          transform: rotateX(10deg) rotateY(-15deg);
          transform-style: preserve-3d;
        }

        .monitor-screen {
          width: 100%;
          height: 70px;
          background: linear-gradient(135deg, #1e293b, #334155);
          border: 3px solid #475569;
          border-radius: 8px;
          position: relative;
          overflow: hidden;
        }

        .code-lines {
          padding: 8px;
        }

        .code-line {
          height: 2px;
          background: linear-gradient(90deg, #3b82f6, #8b5cf6);
          margin: 4px 0;
          border-radius: 1px;
          animation: codeGlow 2s ease-in-out infinite alternate;
        }

        .code-line:nth-child(1) { width: 80%; }
        .code-line:nth-child(2) { width: 60%; }
        .code-line:nth-child(3) { width: 90%; }
        .code-line:nth-child(4) { width: 70%; }

        .monitor-base {
          width: 40px;
          height: 20px;
          background: #475569;
          margin: 0 auto;
          border-radius: 0 0 8px 8px;
          transform: translateZ(-10px);
        }

        .server-rack {
          width: 60px;
          height: 100px;
          background: linear-gradient(135deg, #1e293b, #334155);
          border: 2px solid #475569;
          border-radius: 4px;
          position: relative;
          transform: rotateY(20deg) rotateX(-10deg);
        }

        .server-unit {
          width: 90%;
          height: 20px;
          background: #374151;
          margin: 8px auto;
          border-radius: 2px;
          border: 1px solid #4b5563;
        }

        .server-lights {
          position: absolute;
          top: 10px;
          right: 8px;
          display: flex;
          flex-direction: column;
          gap: 4px;
        }

        .light {
          width: 6px;
          height: 6px;
          border-radius: 50%;
          background: #10b981;
          animation: serverBlink 1.5s ease-in-out infinite alternate;
        }

        .light:nth-child(2) { animation-delay: 0.5s; }
        .light:nth-child(3) { animation-delay: 1s; }

        @keyframes codeGlow {
          0% { opacity: 0.6; }
          100% { opacity: 1; }
        }

        @keyframes serverBlink {
          0% { opacity: 0.3; }
          100% { opacity: 1; }
        }

        .perspective-1000 {
          perspective: 1000px;
        }

        .transform-gpu {
          transform: translateZ(0);
          backface-visibility: hidden;
        }
      `}</style>
    </section>
  );
};

export default HeroSection;

