import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const SkillsSection = () => {
  const sectionRef = useRef(null);
  const skillsGridRef = useRef(null);

  useEffect(() => {
    const skillCards = skillsGridRef.current.children;

    gsap.fromTo(skillCards, 
      { 
        y: 100, 
        opacity: 0, 
        rotationY: 45,
        scale: 0.8
      },
      { 
        y: 0, 
        opacity: 1, 
        rotationY: 0,
        scale: 1,
        duration: 0.8,
        stagger: 0.1,
        ease: "power3.out",
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 80%",
          end: "bottom 20%",
          toggleActions: "play none none reverse"
        }
      }
    );
  }, []);

  const skillCategories = [
    {
      title: "Programming Languages",
      skills: [
        { name: "Python", icon: "🗿", color: "from-blue-500 to-blue-700" },
        { name: "C++", icon: "⚡", color: "from-purple-500 to-purple-700" },
        { name: "C", icon: "🔨", color: "from-gray-500 to-gray-700" },
        { name: "JavaScript", icon: "💎", color: "from-yellow-500 to-yellow-700" }
      ]
    },
    {
      title: "Frontend Technologies",
      skills: [
        { name: "HTML", icon: "🧱", color: "from-orange-500 to-orange-700" },
        { name: "CSS", icon: "🎨", color: "from-pink-500 to-pink-700" },
        { name: "React", icon: "⚛️", color: "from-cyan-500 to-cyan-700" },
        { name: "Tailwind CSS", icon: "🌊", color: "from-teal-500 to-teal-700" }
      ]
    },
    {
      title: "Frameworks & Libraries",
      skills: [
        { name: "Django", icon: "🏛️", color: "from-green-500 to-green-700" },
        { name: "FastAPI", icon: "🚀", color: "from-red-500 to-red-700" },
        { name: "TensorFlow", icon: "🧠", color: "from-indigo-500 to-indigo-700" },
        { name: "Scikit-learn", icon: "📊", color: "from-amber-500 to-amber-700" }
      ]
    },
    {
      title: "Tools & Platforms",
      skills: [
        { name: "Git", icon: "⚒️", color: "from-slate-500 to-slate-700" },
        { name: "Docker", icon: "🐳", color: "from-blue-500 to-blue-700" },
        { name: "AWS", icon: "☁️", color: "from-orange-500 to-orange-700" },
        { name: "Postman", icon: "📮", color: "from-pink-500 to-pink-700" }
      ]
    },
    {
      title: "Data Science & ML",
      skills: [
        { name: "Pandas", icon: "🐼", color: "from-emerald-500 to-emerald-700" },
        { name: "NumPy", icon: "🔢", color: "from-violet-500 to-violet-700" },
        { name: "Matplotlib", icon: "📈", color: "from-rose-500 to-rose-700" },
        { name: "Keras", icon: "🤖", color: "from-lime-500 to-lime-700" }
      ]
    },
    {
      title: "Specializations",
      skills: [
        { name: "Machine Learning", icon: "🎯", color: "from-primary to-primary/80" },
        { name: "GenAI", icon: "✨", color: "from-accent to-accent/80" },
        { name: "EDA", icon: "🔍", color: "from-secondary to-secondary/80" },
        { name: "Web Development", icon: "🌍", color: "from-primary to-accent" }
      ]
    }
  ];

  return (
    <section id="skills" ref={sectionRef} className="min-h-screen py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold tech-text mb-6">
            Technical Skills
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A comprehensive overview of my technical expertise across various domains of 
            software development, machine learning, and data science.
          </p>
        </div>

        <div ref={skillsGridRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, categoryIndex) => (
            <div key={categoryIndex} className="glass-card p-6 transform-3d hover:scale-105 transition-transform duration-300">
              <h3 className="text-xl font-bold text-primary mb-6 text-center">
                {category.title}
              </h3>
              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex} className="group">
                    <div className="flex items-center space-x-4 p-3 rounded-lg hover:bg-primary/5 transition-colors duration-300">
                      {/* Stone-like Icon */}
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${skill.color} flex items-center justify-center text-white text-xl font-bold shadow-lg transform group-hover:scale-110 transition-transform duration-300 stone-texture`}>
                        {skill.icon}
                      </div>
                      
                      {/* Skill Name */}
                      <div className="flex-1">
                        <span className="font-semibold text-lg group-hover:text-primary transition-colors duration-300">
                          {skill.name}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-16 text-center">
          <div className="glass-card p-8 max-w-4xl mx-auto hover:scale-105 transition-transform duration-300">
            <h3 className="text-2xl font-bold tech-text mb-4">
              Continuous Learning
            </h3>
            <p className="text-muted-foreground mb-6">
              I'm constantly expanding my skill set and staying updated with the latest 
              technologies. Currently exploring advanced AI/ML concepts, cloud computing, 
              and modern web development frameworks.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              {[
                { name: "Next.js", color: "from-gray-600 to-gray-800" },
                { name: "GraphQL", color: "from-pink-600 to-pink-800" },
                { name: "Kubernetes", color: "from-blue-600 to-blue-800" },
                { name: "PyTorch", color: "from-red-600 to-red-800" },
                { name: "React Native", color: "from-cyan-600 to-cyan-800" }
              ].map((tech, index) => (
                <span 
                  key={index} 
                  className={`glass px-4 py-2 rounded-full text-sm font-medium hover:scale-110 transition-transform duration-300 cursor-pointer bg-gradient-to-r ${tech.color} text-white stone-texture`}
                >
                  {tech.name}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* CSS Styles for Stone Texture */}
      <style jsx>{`
        .stone-texture {
          position: relative;
          box-shadow: 
            inset 0 2px 4px rgba(255, 255, 255, 0.1),
            inset 0 -2px 4px rgba(0, 0, 0, 0.2),
            0 4px 8px rgba(0, 0, 0, 0.3);
        }
        
        .stone-texture::before {
          content: '';
          position: absolute;
          inset: 0;
          border-radius: inherit;
          background: 
            radial-gradient(circle at 20% 30%, rgba(255, 255, 255, 0.1) 1px, transparent 1px),
            radial-gradient(circle at 80% 70%, rgba(0, 0, 0, 0.1) 1px, transparent 1px),
            radial-gradient(circle at 40% 80%, rgba(255, 255, 255, 0.05) 2px, transparent 2px);
          pointer-events: none;
        }
        
        .stone-texture:hover {
          box-shadow: 
            inset 0 2px 6px rgba(255, 255, 255, 0.15),
            inset 0 -2px 6px rgba(0, 0, 0, 0.25),
            0 6px 12px rgba(0, 0, 0, 0.4);
        }
      `}</style>
    </section>
  );
};

export default SkillsSection;

