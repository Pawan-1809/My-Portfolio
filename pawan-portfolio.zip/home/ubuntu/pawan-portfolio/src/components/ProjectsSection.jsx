import { useState, useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ExternalLink, Github, X } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const ProjectsSection = () => {
  const [selectedProject, setSelectedProject] = useState(null);
  const sectionRef = useRef(null);
  const projectsGridRef = useRef(null);

  useEffect(() => {
    const projectCards = projectsGridRef.current.children;

    gsap.fromTo(projectCards, 
      { 
        y: 80, 
        opacity: 0, 
        scale: 0.9,
        rotationX: 45
      },
      { 
        y: 0, 
        opacity: 1, 
        scale: 1,
        rotationX: 0,
        duration: 0.8,
        stagger: 0.15,
        ease: "power3.out",
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 70%",
          end: "bottom 30%",
          toggleActions: "play none none reverse"
        }
      }
    );
  }, []);

  const projects = [
    {
      id: 1,
      title: "College Student Management Portal",
      description: "Role-based web application for students, staff, and HODs with Bootstrap UI and integrated charts.",
      longDescription: "A comprehensive web application built with Django that provides role-based access control for different user types including students, staff, and Heads of Departments. Features include student enrollment management, grade tracking, attendance monitoring, and administrative dashboards with interactive charts and analytics.",
      tech: ["Django", "Python", "Bootstrap", "JavaScript", "SQLite"],
      category: "Web Development",
      image: "/api/placeholder/400/250",
      github: "https://github.com/Pawan-1809/college-portal",
      live: "https://college-portal-demo.com",
      features: [
        "Role-based authentication system",
        "Student enrollment and management",
        "Grade and attendance tracking",
        "Interactive dashboard with charts",
        "Responsive Bootstrap UI"
      ]
    },
    {
      id: 2,
      title: "Disease Prediction Model",
      description: "ML model predicting diseases using Random Forest, XGBoost, and voting classifiers.",
      longDescription: "An advanced machine learning system that predicts potential diseases based on symptoms and patient data. The model uses ensemble methods combining Random Forest, XGBoost, and voting classifiers to achieve high accuracy in disease prediction, helping in early diagnosis and treatment recommendations.",
      tech: ["Python", "Scikit-learn", "XGBoost", "Pandas", "NumPy"],
      category: "Machine Learning",
      image: "/api/placeholder/400/250",
      github: "https://github.com/Pawan-1809/disease-prediction",
      live: "https://disease-predictor-demo.com",
      features: [
        "Ensemble ML algorithms",
        "Symptom-based prediction",
        "High accuracy disease classification",
        "Interactive web interface",
        "Medical data visualization"
      ]
    },
    {
      id: 3,
      title: "AgroHelp - Smart Farming Assistant",
      description: "Website detecting plant diseases, providing weather forecasts, crop suggestions, and IoT-based automations.",
      longDescription: "A comprehensive smart farming solution that combines AI-powered plant disease detection, real-time weather forecasting, intelligent crop recommendations, and IoT-based automation systems. The platform helps farmers make data-driven decisions to improve crop yield and reduce losses.",
      tech: ["Python", "TensorFlow", "IoT", "Weather API", "Computer Vision"],
      category: "AI/IoT",
      image: "/api/placeholder/400/250",
      github: "https://github.com/Pawan-1809/agrohelp",
      live: "https://agrohelp-demo.com",
      features: [
        "AI-powered disease detection",
        "Real-time weather integration",
        "Crop recommendation system",
        "IoT sensor automation",
        "Farmer dashboard and analytics"
      ]
    },
    {
      id: 4,
      title: "Resume Rating using Machine Learning",
      description: "ML model evaluating resumes and scoring them based on relevance to job descriptions.",
      longDescription: "An intelligent resume screening system that uses natural language processing and machine learning to evaluate resumes against job descriptions. The system provides detailed scoring, keyword analysis, and improvement suggestions to help both recruiters and job seekers.",
      tech: ["Python", "NLP", "Scikit-learn", "NLTK", "Flask"],
      category: "Machine Learning",
      image: "/api/placeholder/400/250",
      github: "https://github.com/Pawan-1809/resume-rating",
      live: "https://resume-rater-demo.com",
      features: [
        "NLP-based resume analysis",
        "Job description matching",
        "Automated scoring system",
        "Keyword extraction and analysis",
        "Improvement recommendations"
      ]
    },
    {
      id: 5,
      title: "Weather Web App",
      description: "Web app fetching weather data and forecast built using FastAPI and Streamlit.",
      longDescription: "A modern weather application that provides real-time weather data, detailed forecasts, and interactive visualizations. Built with FastAPI for the backend and Streamlit for the frontend, offering a seamless user experience with responsive design and accurate weather predictions.",
      tech: ["FastAPI", "Streamlit", "Python", "Weather API", "Plotly"],
      category: "Web Development",
      image: "/api/placeholder/400/250",
      github: "https://github.com/Pawan-1809/weather-app",
      live: "https://weather-app-demo.com",
      features: [
        "Real-time weather data",
        "7-day weather forecast",
        "Interactive weather maps",
        "Location-based services",
        "Weather alerts and notifications"
      ]
    },
    {
      id: 6,
      title: "Web Scraping Amazon Reviews",
      description: "Python tool extracting product reviews and ratings for sentiment analysis.",
      longDescription: "A sophisticated web scraping tool that extracts product reviews and ratings from Amazon, performs sentiment analysis, and generates insights about customer opinions. The tool includes data cleaning, sentiment classification, and visualization of review trends.",
      tech: ["Python", "BeautifulSoup", "Selenium", "Pandas", "NLTK"],
      category: "Data Science",
      image: "/api/placeholder/400/250",
      github: "https://github.com/Pawan-1809/amazon-scraper",
      live: null,
      features: [
        "Automated review extraction",
        "Sentiment analysis",
        "Review trend visualization",
        "Product rating analytics",
        "Export to multiple formats"
      ]
    }
  ];

  const categories = ["All", "Web Development", "Machine Learning", "AI/IoT", "Data Science"];
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredProjects = activeCategory === "All" 
    ? projects 
    : projects.filter(project => project.category === activeCategory);

  return (
    <section id="projects" ref={sectionRef} className="min-h-screen py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold tech-text mb-6">
            Featured Projects
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            A showcase of my technical projects spanning web development, machine learning, 
            and data science. Each project demonstrates different aspects of my skills and expertise.
          </p>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                  activeCategory === category
                    ? 'glass-button'
                    : 'glass hover:glass-button'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Projects Grid */}
        <div ref={projectsGridRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="glass-card p-6 cursor-pointer transform-3d group hover:scale-105 hover:rotate-1 transition-all duration-500 ease-out hover:shadow-2xl hover:shadow-primary/20"
              onClick={() => setSelectedProject(project)}
            >
              <div className="relative mb-4 overflow-hidden rounded-lg group-hover:scale-110 transition-transform duration-500">
                <div className="w-full h-48 bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center relative">
                  <span className="text-4xl opacity-50 group-hover:scale-125 group-hover:rotate-12 transition-all duration-500">🚀</span>
                  
                  {/* Animated overlay */}
                  <div className="absolute inset-0 bg-gradient-to-r from-primary/30 to-accent/30 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  
                  {/* Floating particles on hover */}
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                    <div className="absolute top-2 left-2 w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
                    <div className="absolute top-4 right-4 w-1 h-1 bg-accent rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    <div className="absolute bottom-3 left-6 w-1.5 h-1.5 bg-secondary rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs px-3 py-1 rounded-full glass text-primary font-medium group-hover:scale-110 group-hover:bg-primary/20 transition-all duration-300">
                    {project.category}
                  </span>
                </div>

                <h3 className="text-xl font-bold group-hover:text-primary transition-colors duration-300 group-hover:translate-x-2 transform">
                  {project.title}
                </h3>

                <p className="text-muted-foreground text-sm line-clamp-3 group-hover:text-foreground/80 transition-colors duration-300">
                  {project.description}
                </p>

                <div className="flex flex-wrap gap-2">
                  {project.tech.slice(0, 3).map((tech, index) => (
                    <span 
                      key={index} 
                      className="text-xs px-2 py-1 rounded bg-muted text-muted-foreground group-hover:bg-primary/10 group-hover:text-primary group-hover:scale-105 transition-all duration-300"
                      style={{ transitionDelay: `${index * 50}ms` }}
                    >
                      {tech}
                    </span>
                  ))}
                  {project.tech.length > 3 && (
                    <span className="text-xs px-2 py-1 rounded bg-muted text-muted-foreground group-hover:bg-accent/10 group-hover:text-accent transition-all duration-300">
                      +{project.tech.length - 3}
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between pt-4">
                  <span className="text-sm text-primary font-medium group-hover:translate-x-2 transform transition-transform duration-300">
                    View Details →
                  </span>
                  <div className="flex space-x-2">
                    {project.github && (
                      <Github 
                        size={16} 
                        className="text-muted-foreground hover:text-primary transition-all duration-300 hover:scale-125 hover:rotate-12" 
                      />
                    )}
                    {project.live && (
                      <ExternalLink 
                        size={16} 
                        className="text-muted-foreground hover:text-primary transition-all duration-300 hover:scale-125 hover:-rotate-12" 
                      />
                    )}
                  </div>
                </div>
              </div>

              {/* Hover glow effect */}
              <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-primary/5 to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
            </div>
          ))}
        </div>

        {/* Project Modal */}
        {selectedProject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
            <div className="glass max-w-4xl w-full max-h-[90vh] overflow-y-auto rounded-2xl p-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-3xl font-bold tech-text">
                  {selectedProject.title}
                </h3>
                <button
                  onClick={() => setSelectedProject(null)}
                  className="glass-button p-2 rounded-full"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <div className="w-full h-64 bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg flex items-center justify-center mb-6">
                    <span className="text-6xl opacity-50">🚀</span>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <h4 className="text-lg font-semibold mb-2">Technologies Used</h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedProject.tech.map((tech, index) => (
                          <span key={index} className="glass px-3 py-1 rounded-full text-sm">
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="flex space-x-4">
                      {selectedProject.github && (
                        <a
                          href={selectedProject.github}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="glass-button px-6 py-3 rounded-full flex items-center space-x-2"
                        >
                          <Github size={20} />
                          <span>View Code</span>
                        </a>
                      )}
                      {selectedProject.live && (
                        <a
                          href={selectedProject.live}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="glass px-6 py-3 rounded-full flex items-center space-x-2"
                        >
                          <ExternalLink size={20} />
                          <span>Live Demo</span>
                        </a>
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <div>
                    <h4 className="text-lg font-semibold mb-3">Project Overview</h4>
                    <p className="text-muted-foreground leading-relaxed">
                      {selectedProject.longDescription}
                    </p>
                  </div>

                  <div>
                    <h4 className="text-lg font-semibold mb-3">Key Features</h4>
                    <ul className="space-y-2">
                      {selectedProject.features.map((feature, index) => (
                        <li key={index} className="flex items-center space-x-2 text-muted-foreground">
                          <span className="w-2 h-2 bg-primary rounded-full"></span>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default ProjectsSection;

