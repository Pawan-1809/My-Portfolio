import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User } from 'lucide-react';

const ChatBot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: "Hi! I'm Pawan's AI assistant. I can help you learn more about his skills, projects, and experience. How can I assist you today?",
      sender: 'bot',
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Predefined responses based on Pawan's information
  const getResponse = (message) => {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('skill') || lowerMessage.includes('technology')) {
      return "Pawan is skilled in Python, C++, Django, FastAPI, Machine Learning, and AI. He has experience with TensorFlow, Scikit-learn, React, and various data science tools. He's currently working as an SDE Intern at BlueStock and has completed the Google Cloud Skill Boost Program.";
    }
    
    if (lowerMessage.includes('project')) {
      return "Pawan has worked on several impressive projects including:\n• College Student Management Portal (Django)\n• Disease Prediction Model using ML\n• AgroHelp - Smart Farming Assistant\n• Resume Rating using Machine Learning\n• Weather Web App with FastAPI\n• Web Scraping tools for Amazon reviews\n\nWould you like to know more about any specific project?";
    }
    
    if (lowerMessage.includes('education') || lowerMessage.includes('college')) {
      return "Pawan is currently pursuing B.Tech at Heritage Institute of Technology, Kolkata under MAKAUT University with an impressive 8.67 CGPA. He completed his 12th from Yogoda Satsanga Mahavidyalaya, Ranchi with 82.4% and 10th from Saraswati Shishu Vidya Mandir, Ranchi with 80%.";
    }
    
    if (lowerMessage.includes('experience') || lowerMessage.includes('work')) {
      return "Pawan is currently working as an SDE Intern at BlueStock, Kolkata since July 2025. He has also completed the Google Cloud Skill Boost Program where he gained hands-on experience with Google Cloud services, AI/ML capabilities, and built scalable applications.";
    }
    
    if (lowerMessage.includes('contact') || lowerMessage.includes('email') || lowerMessage.includes('phone')) {
      return "You can reach Pawan through:\n📧 Email: pawankr16123114@gmail.com\n📱 WhatsApp: +91 7857917511\n💼 LinkedIn: linkedin.com/in/pawan-kumar-467a84244\n🐙 GitHub: github.com/Pawan-1809\n\nWould you like me to help you compose a message?";
    }
    
    if (lowerMessage.includes('achievement') || lowerMessage.includes('award')) {
      return "Pawan has several notable achievements:\n🏆 Google Cloud Skill Boost Program completion\n🥈 On-campus Regression Challenge Runner-up\n🥈 Inter-college ML Competition Runner-up\n🚀 Innovathon hackathon finalist 2024\n📜 Multiple certifications in AI, HTML/CSS/JS, and Data Science";
    }
    
    if (lowerMessage.includes('hire') || lowerMessage.includes('available')) {
      return "Yes! Pawan is currently available for freelance projects, internships, and full-time opportunities. He's passionate about AI/ML development and web development. You can contact him directly through the contact form or reach out via email/WhatsApp for immediate response.";
    }
    
    if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey')) {
      return "Hello! Great to meet you! I'm here to help you learn more about Pawan Kumar. You can ask me about his skills, projects, education, work experience, or how to get in touch with him. What would you like to know?";
    }
    
    // Default response
    return "That's an interesting question! While I'd love to help with that, I'm specifically designed to share information about Pawan Kumar's professional background. You can ask me about his:\n• Technical skills and expertise\n• Projects and achievements\n• Education and experience\n• Contact information\n\nWhat would you like to know about Pawan?";
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage = {
      id: messages.length + 1,
      text: inputMessage,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate typing delay
    setTimeout(() => {
      const botResponse = {
        id: messages.length + 2,
        text: getResponse(inputMessage),
        sender: 'bot',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000); // Random delay between 1-2 seconds
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Chat Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 z-50 glass-button p-4 rounded-full shadow-lg transition-all duration-300 ${
          isOpen ? 'scale-0' : 'scale-100 hover:scale-110'
        }`}
      >
        <MessageCircle size={24} />
      </button>

      {/* Chat Modal */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-96 h-[500px] glass rounded-2xl shadow-2xl flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-border">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center">
                <Bot size={20} className="text-white" />
              </div>
              <div>
                <h3 className="font-semibold">Pawan's AI Assistant</h3>
                <p className="text-xs text-muted-foreground">Always online</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="glass-button p-2 rounded-full"
            >
              <X size={16} />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-2xl ${
                    message.sender === 'user'
                      ? 'glass-button text-white'
                      : 'glass'
                  }`}
                >
                  <div className="flex items-start space-x-2">
                    {message.sender === 'bot' && (
                      <Bot size={16} className="text-primary mt-1 flex-shrink-0" />
                    )}
                    {message.sender === 'user' && (
                      <User size={16} className="text-white mt-1 flex-shrink-0" />
                    )}
                    <div className="text-sm whitespace-pre-line">
                      {message.text}
                    </div>
                  </div>
                  <div className="text-xs opacity-70 mt-1">
                    {message.timestamp.toLocaleTimeString([], { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </div>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="glass p-3 rounded-2xl">
                  <div className="flex items-center space-x-2">
                    <Bot size={16} className="text-primary" />
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-border">
            <div className="flex space-x-2">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask me about Pawan..."
                className="flex-1 px-3 py-2 glass rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              />
              <button
                onClick={handleSendMessage}
                disabled={!inputMessage.trim()}
                className="glass-button p-2 rounded-full disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ChatBot;

